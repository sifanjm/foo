package com.example.springboot;

import java.lang.*;
import java.util.*;
import java.util.stream.Collectors;

class Solution {

    static class Fraction {
        int x, y;

        public Fraction(int x, int y) {
            this.x = x;
            this.y = y;
        }

        @Override
        public int hashCode() {
            return this.x;
        }

        @Override
        public boolean equals(Object obj) {

            if (this == obj)
                return true;

            if (obj == null || obj.getClass() != this.getClass()) {
                return false;
            }
            Fraction fraction = (Fraction) obj;
            return (fraction.x == this.x && fraction.y == this.y);
        }

    }

    static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }


    static int fractionCount(int x[], int y[]) {

        int count = 0;

        if (x.length != y.length) {
            throw new RuntimeException("arrays size not equal");
        }

        Map<Fraction, Integer> map = new HashMap<>();

        for (int i = 0; i < x.length; i++) {

            if (x[i] == 0) {
                map.put(new Fraction(0,0),1);
            } else{

                int number = x[i] / gcd(x[i], y[i]);
            int denom = y[i] / gcd(x[i], y[i]);

            if (denom < 0) {
                number *= -1;
            }

            Fraction tmp = new Fraction(number, denom);

            if (map.containsKey(tmp)) {
                map.put(tmp, map.get(tmp) + 1);
            } else {
                map.put(tmp, 1);
            }
        }
        }

        Map.Entry<Fraction, Integer> maxEntry = map.entrySet()
                .stream()
                .max(Map.Entry.comparingByValue()).get();

        if (maxEntry != null) {

            count=  maxEntry.getValue();
        }

        return count;
    }
}


