package com.example.springboot;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class SolutionTest {


    @Test
    public void test1() throws Exception {
        int x[] = {4, 4, 7, 1, 2};
        int y[] = {4, 4, 8, 1, 2};

        int result = Solution.fractionCount(x, y);

        Assertions.assertEquals(4, result);
    }

    @Test
    public void test2() throws Exception {
        int x[] = {3, 3, 4};
        int y[] = {5, 4, 3};

        int result = Solution.fractionCount(x, y);

        Assertions.assertEquals(1, result);
    }


    @Test
    public void test3() throws Exception {
        int x[] = {1, 2, 3,1,2};
        int y[] = {2, 4, 6,5,10};

        int result = Solution.fractionCount(x, y);

        Assertions.assertEquals(3, result);
    }

    @Test
    public void test4() throws Exception {
        int x[] = {1, 2, 3,1,6};
        int y[] = {2, 4, 6,5,12};

        int result = Solution.fractionCount(x, y);

        Assertions.assertEquals(4, result);
    }

    @Test
    public void test5() throws Exception {
        int x[] = {1, 2, 3,18,6};
        int y[] = {2, 4, 6,36,12};

        int result = Solution.fractionCount(x, y);

        Assertions.assertEquals(5, result);
    }

    @Test
    public void test6() throws Exception {
        int x[] = {0, 2, 3,18,6};
        int y[] = {1, 4, 6,36,12};

        int result = Solution.fractionCount(x, y);

        Assertions.assertEquals(4, result);
    }

    @Test
    public void test7() throws Exception {
        int x[] = {0, 2, 3,18,6};
        int y[] = {1, 0, 6,36,12};

        int result = Solution.fractionCount(x, y);

        Assertions.assertEquals(3, result);
    }
}
